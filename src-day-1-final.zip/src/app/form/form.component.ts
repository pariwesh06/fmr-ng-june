import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.css']
})
export class FormComponent {
  title = 'app';
  criterion = {
    fname: 'ram',
    limit: 10
  };
  songs = [];
  save() {
    this.songs.push(Object.assign({},this.criterion));
  }
}
