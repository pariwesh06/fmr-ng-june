import { Pipe, PipeTransform } from '@angular/core';
import { CurrencyPipe } from "@angular/common";
@Pipe({
  name: 'currencyConversion'
})
export class CurrencyConversionPipe implements PipeTransform {

  transform(value: any, args?: any): any {
      // console.log(value);
      // const currencyPipe = new CurrencyPipe ('fr');
    // return  currencyPipe.transform(value*70, 'INR');
    return value*70;
  }

}
