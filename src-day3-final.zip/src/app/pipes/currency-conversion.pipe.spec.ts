import { CurrencyConversionPipe } from './currency-conversion.pipe';
//test suite => tests
describe('CurrencyConversionPipe', () => {
  it('create an instance', () => {
    //prepare fixture -> call MUT -> verify

    const pipe = new CurrencyConversionPipe();
    const result = pipe.transform(1);

    expect(result).toEqual(70);
  });

});
