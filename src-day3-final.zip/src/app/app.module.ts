import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { FormComponent } from './form/form.component';
import { HttpModule } from "@angular/http";
import { CurrencyConversionPipe } from './pipes/currency-conversion.pipe';
import { RouterModule, Routes } from '@angular/router';

const appRoutes: Routes = [
  { path: 'search', component: FormComponent },
  { path: '' , component:AppComponent}
]
@NgModule({
  declarations: [
    AppComponent,
    FormComponent,
    CurrencyConversionPipe
  ],
  imports: [
    BrowserModule, FormsModule, HttpModule,
    RouterModule.forRoot(
      appRoutes,
      { enableTracing: true } // <-- debugging purposes only
    )
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
