import { Injectable } from '@angular/core';
import { Http } from "@angular/http";
import { Observable } from "rxjs";
@Injectable({
  providedIn: 'root'
})
export class ItunesService {
  //100-399
  constructor(private http: Http) { }
  search(criterion) {
    if (!criterion.fname) {
      throw Error('searchTerm is required');
    }
    return this.http.get(`https://itunes.apple.com/search?term=${criterion.fname}&limit=${criterion.limit}`);
    // return this.http.get('/assets/data.json');
  }
}
