import { Component, OnInit } from '@angular/core';
import { ItunesService } from '../services/itunes.service';
@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.css']
})
export class FormComponent {
  criterion = { //model
    fname: 'ram',
    limit: 10,
    gender: 'Male'
  };
  songs = [];//model
  constructor(private service: ItunesService) { };
  toggle = true;
  sort() {
    this.toggle = !this.toggle;
    this.songs.sort((song1, song2) => this.toggle ? song1.trackPrice - song2.trackPrice : song2.trackPrice - song1.trackPrice);
  }
  deleteSong(index){
    this.songs.splice(index, 1);
  }
  save() {
    // this.songs.push(Object.assign({}, this.criterion));
    // this.criterion={};
    const observable = this.service.search(Object.assign({}, this.criterion));
    observable.subscribe((response) => this.songs = response.json().results,
      error => console.log(error));
  }
}
